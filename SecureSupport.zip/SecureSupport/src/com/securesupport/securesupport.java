package com.securesupport;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

class Ticket {
    private String description;
    private String status;

    public Ticket(String description) {
        this.description = description;
        this.status = "Open";
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public void closeTicket() {
        this.status = "Closed";
    }
}

public class securesupport {
    private static Map<String, User> users = new HashMap<>();
    private static Map<String, Ticket> tickets = new HashMap<>();
    private static User currentUser = null;

    public static void main(String[] args) {
        // Create some sample users
        users.put("user1", new User("user1", "password1"));
        users.put("user2", new User("user2", "password2"));

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Secure User Support System");
            System.out.println("1. Login");
            System.out.println("2. Create Ticket");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (option) {
                case 1:
                    login(scanner);
                    break;
                case 2:
                    createTicket(scanner);
                    break;
                case 3:
                    System.out.println("Exiting the Support System.");
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void login(Scanner scanner) {
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        User user = users.get(username);

        if (user != null && user.getPassword().equals(password)) {
            currentUser = user;
            System.out.println("Login successful.");
        } else {
            System.out.println("Invalid username or password. Please try again.");
        }
    }

    private static void createTicket(Scanner scanner) {
        if (currentUser == null) {
            System.out.println("Please log in before creating a ticket.");
            return;
        }

        System.out.print("Enter a description for the ticket: ");
        String description = scanner.nextLine();

        Ticket ticket = new Ticket(description);
        tickets.put(description, ticket);

        System.out.println("Ticket created successfully.");
    }
}
