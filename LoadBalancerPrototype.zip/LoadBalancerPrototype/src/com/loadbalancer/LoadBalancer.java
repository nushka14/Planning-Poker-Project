package com.loadbalancer;
import java.util.Queue;
import java.util.LinkedList;

class Server {
    private String name;
    private Queue<String> requests;

    public Server(String name) {
        this.name = name;
        this.requests = new LinkedList<>();
    }

    public void addRequest(String request) {
        requests.add(request);
        System.out.println(name + " received " + request);
    }
}

public class LoadBalancer {
    private Server[] servers;
    
    public LoadBalancer(int numServers) {
        servers = new Server[numServers];
        for(int i = 0; i < numServers; i++) {
            servers[i] = new Server("Server" + (i + 1));
        }
    }

    public void distributeRequest(String request) {
        int index = (int)(Math.random() * servers.length);
        servers[index].addRequest(request);
    }

    public static void main(String[] args) {
        LoadBalancer lb = new LoadBalancer(3);

        for(int i = 0; i < 10; i++) {
            lb.distributeRequest("Request" + (i + 1));
        }
    }
}
