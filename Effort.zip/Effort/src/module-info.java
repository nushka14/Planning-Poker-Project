/**
 * 
 */
/**
 * 
 */
module Effort {
}